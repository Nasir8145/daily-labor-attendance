
import React from "react";
export default function Home() {
  return (
    <main className="min-h-screen bg-gray-100 p-4">
      <h1 className="text-2xl font-bold mb-4 text-center">Good Will Builder - Daily Labor Attendance</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white shadow-xl rounded-2xl p-4">
          <h2 className="text-xl font-semibold mb-2">Admin Panel</h2>
          <p>Add or edit attendance for each labor daily. View reports by date or subcontractor.</p>
          <button className="mt-4 w-full bg-blue-500 text-white p-2 rounded">Go to Admin Panel</button>
        </div>
        <div className="bg-white shadow-xl rounded-2xl p-4">
          <h2 className="text-xl font-semibold mb-2">Subcontractor Login</h2>
          <p>View your daily attendance, rate, and bill summary by mobile number or ID.</p>
          <button className="mt-4 w-full bg-green-500 text-white p-2 rounded">Login</button>
        </div>
      </div>
    </main>
  );
}
